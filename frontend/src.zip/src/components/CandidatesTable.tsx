import React from "react";
import { Checkbox, IconButton, Table, TableBody, TableCell, TableHead, TableRow } from "@mui/material";
import DeleteIcon from "@mui/icons-material/Delete";
import SelectAllIcon from "@mui/icons-material/DoneAll";
import DeselectAllIcon from "@mui/icons-material/RemoveDone";
import { Candidate } from "../types";

type Props = {
  candidates: Candidate[];
  selectedIds: string[];
  onSelect: (id: string) => void;
  onSelectAll: () => void;
  onDeselectAll: () => void;
  onDelete: (ids: string[]) => void;
  onRowClick: (id: string) => void;
};

export default function CandidatesTable({
  candidates,
  selectedIds,
  onSelect,
  onSelectAll,
  onDeselectAll,
  onDelete,
  onRowClick,
}: Props) {
  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 8 }}>
        <IconButton onClick={onSelectAll} title="Select all">
          <SelectAllIcon />
        </IconButton>
        <IconButton onClick={onDeselectAll} title="Deselect all">
          <DeselectAllIcon />
        </IconButton>
        <IconButton onClick={() => onDelete(selectedIds)} disabled={selectedIds.length === 0} title="Delete selected">
          <DeleteIcon />
        </IconButton>
      </div>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell></TableCell>
            <TableCell>Name</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>Country</TableCell>
            <TableCell>Birth date</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {candidates.map(candidate => (
            <TableRow
              key={candidate.candidate_id}
              hover
              selected={selectedIds.includes(candidate.candidate_id)}
              onClick={() => onRowClick(candidate.candidate_id)}
              style={{ cursor: "pointer" }}
            >
              <TableCell>
                <Checkbox
                  checked={selectedIds.includes(candidate.candidate_id)}
                  onChange={e => {
                    e.stopPropagation();
                    onSelect(candidate.candidate_id);
                  }}
                />
              </TableCell>
              <TableCell>{candidate.candidate_name}</TableCell>
              <TableCell>{candidate.email}</TableCell>
              <TableCell>{candidate.country}</TableCell>
              <TableCell>{candidate.birth_date}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}