import React, { useState } from "react";
import CandidatesTable from ".components/CandidatesTable";
import CandidateDetailsPanel from ".components/CandidateDetailsPanel";
import LoginForm from "./LoginForm";
import ApplicationBar from "./ApplicationBar";
import { useAuth } from "./AuthContext";

const App: React.FC = () => {
  const { token, handleLogin, handleLogout } = useAuth();

  const [selectedCandidate, setSelectedCandidate] = useState(null);

  if (!token) {
    return <LoginForm onLogin={handleLogin} />;
  }

  return (
    <div>
      <ApplicationBar onLogout={handleLogout} />
      <div style={{ display: "flex" }}>
        <CandidatesTable
          onSelectCandidate={setSelectedCandidate}
          // + передавай сюда функции выделения, удаления, select all и т.д.
        />
        <CandidateDetailsPanel
          candidate={selectedCandidate}
          // + остальные props (например, функции обновления кандидата)
        />
      </div>
    </div>
  );
};

export default App;