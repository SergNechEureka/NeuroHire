// src/api/candidates.ts

import axios from "axios";
import type { Candidate, CV, CVExperience, CVSkill } from "../types";

const API_URL = "/api"; // Можно вынести в .env или config

export async function fetchCandidates(): Promise<Candidate[]> {
    const response = await axios.get<Candidate[]>(`${API_URL}/candidates`);
    return response.data;
}

export async function deleteCandidates(candidateIds: string[]): Promise<void> {
    await axios.post(`${API_URL}/candidates/delete`, { candidate_ids: candidateIds });
}

export async function fetchCandidateDetails(candidateId: string): Promise<Candidate> {
    const response = await axios.get<Candidate>(`${API_URL}/candidates/${candidateId}`);
    return response.data;
}

export async function fetchCandidateCVs(candidateId: string): Promise<CV[]> {
    const response = await axios.get<CV[]>(`${API_URL}/candidates/${candidateId}/cvs`);
    return response.data;
}

export async function fetchCVExperiences(cvId: string): Promise<CVExperience[]> {
    const response = await axios.get<CVExperience[]>(`${API_URL}/cvs/${cvId}/experience`);
    return response.data;
}

export async function fetchCVSkills(cvId: string): Promise<CVSkill[]> {
    const response = await axios.get<CVSkill[]>(`${API_URL}/cvs/${cvId}/skills`);
    return response.data;
}

export async function deleteCVs(cvIds: string[]): Promise<void> {
    await axios.post(`${API_URL}/cvs/delete`, { cv_ids: cvIds });
}