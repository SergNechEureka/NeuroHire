import { useState, useEffect } from "react";
import { Candidate } from "../types";
import { fetchCandidates, deleteCandidates } from "../api/candidates";

export function useCandidates() {
  const [candidates, setCandidates] = useState<Candidate[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    setLoading(true);
    fetchCandidates().then(data => {
      setCandidates(data);
      setLoading(false);
    });
  }, []);

  const removeCandidates = async (ids: string[]) => {
    await deleteCandidates(ids);
    setCandidates(prev => prev.filter(c => !ids.includes(c.candidate_id)));
  };

  return { candidates, loading, removeCandidates, setCandidates };
}