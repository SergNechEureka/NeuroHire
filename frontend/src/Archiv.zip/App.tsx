import React, { useState } from "react";
import CandidatesTable from "./components/CandidatesTable";
import CandidateDetailsDrawer from "./components/CandidateDetailsDrawer";
import LoginForm from "./LoginForm";
import ApplicationBar from "./ApplicationBar";
import { useAuth } from "./AuthContext";
import { Candidate } from "./types";

const App: React.FC = () => {
  const { token, handleLogin, handleLogout } = useAuth();
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);

  return (
    <div>
      {!token ? (
        <LoginForm onLogin={handleLogin} />
      ) : (
        <>
          <ApplicationBar onLogout={handleLogout} />
          <div style={{ display: "flex", height: "100vh" }}>
            <CandidatesTable
              onSelectCandidate={setSelectedCandidate}
              selectedCandidate={selectedCandidate}
            />
            <CandidateDetailsDrawer
              candidate={selectedCandidate}
            />
          </div>
        </>
      )}
    </div>
  );
};

export default App;